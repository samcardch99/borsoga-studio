export const C = {
  bg: '#FAF8F4',      // blanco cálido
  sand: '#EDE6DA',    // arena suave
  stone: '#D8D5CF',   // gris piedra
  ink: '#26251F',     // grafito profundo
  sage: '#3F4A42',    // verde salvia oscuro
  gold: '#A98A56',    // dorado apagado
  white: '#FFFFFF',
  green: '#3E7A52',
  red: '#A65B4B',
};

export const F = {
  display: "'Poppins', sans-serif",
  body: "'Poppins', sans-serif",
};
