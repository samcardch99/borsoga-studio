import React from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import '@fontsource/poppins/400.css';
import '@fontsource/poppins/500.css';
import '@fontsource/poppins/600.css';
import '@fontsource/poppins/700.css';
import '@fontsource/poppins/800.css';
import {C} from './theme';
import {T1Hook, T2Chaos, T3Routes, T4Evv, T5Turn, T6Rpm, T7Billing, T8Close} from './scenes2';

export const Video2: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: C.bg}}>
      <Sequence from={0} durationInFrames={240}><T1Hook /></Sequence>
      <Sequence from={240} durationInFrames={360}><T2Chaos /></Sequence>
      <Sequence from={600} durationInFrames={480}><T3Routes /></Sequence>
      <Sequence from={1080} durationInFrames={360}><T4Evv /></Sequence>
      <Sequence from={1440} durationInFrames={240}><T5Turn /></Sequence>
      <Sequence from={1680} durationInFrames={480}><T6Rpm /></Sequence>
      <Sequence from={2160} durationInFrames={420}><T7Billing /></Sequence>
      <Sequence from={2580} durationInFrames={270}><T8Close /></Sequence>
    </AbsoluteFill>
  );
};
