import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {C, F} from './theme';
import {Scene, Kicker, Caption, GoldRule, Card, Pill, Check, BrowserFrame, useFadeUp, usePop} from './ui';
import logoBorsoga from './logo-borsoga.svg';
import logoYhp from './logo-yhp.png';

const YhpLogo: React.FC<{width?: number}> = ({width = 620}) => (
  // eslint-disable-next-line @remotion/warn-native-media-tag
  <img src={logoYhp} style={{width, height: 'auto', display: 'block'}} />
);
const BorsogaLogo: React.FC<{width?: number}> = ({width = 310}) => (
  // eslint-disable-next-line @remotion/warn-native-media-tag
  <img src={logoBorsoga} style={{width, height: 'auto', display: 'block'}} />
);

// ================= T1 — GANCHO (240f) =================

export const T1Hook: React.FC = () => {
  const t1 = useFadeUp(10);
  const t2 = useFadeUp(45);
  const t3 = useFadeUp(85);
  return (
    <Scene duration={240}>
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', gap: 36}}>
        <div style={t1}><YhpLogo width={560} /></div>
        <GoldRule delay={30} width={160} />
        <div style={{...t2, fontFamily: F.display, fontSize: 66, color: C.ink, fontWeight: 700, textAlign: 'center', maxWidth: 1500, lineHeight: 1.22}}>
          ¿Y si su equipo pudiera atender <span style={{color: C.gold}}>más pacientes</span>
          <br />
          — sin contratar a nadie más?
        </div>
        <div style={{...t3, fontFamily: F.body, fontSize: 28, color: C.sage}}>
          El cuidado continuo · Una demostración de 95 segundos
        </div>
      </AbsoluteFill>
    </Scene>
  );
};

// ================= T2 — EL CAOS (360f) =================

const Sticky: React.FC<{delay: number; x: number; y: number; rot: number; color: string; children: React.ReactNode}> = ({delay, x, y, rot, color, children}) => {
  const frame = useCurrentFrame();
  const st = usePop(delay);
  const wob = Math.sin((frame + x) * 0.09) * 1.6;
  return (
    <div style={{position: 'absolute', left: x, top: y, ...st}}>
      <div
        style={{
          width: 250,
          padding: '22px 20px',
          background: color,
          transform: `rotate(${rot + wob}deg)`,
          boxShadow: '0 10px 26px rgba(38,37,31,0.18)',
          fontFamily: F.body,
          fontSize: 22,
          fontWeight: 500,
          color: C.ink,
          lineHeight: 1.35,
        }}
      >
        {children}
      </div>
    </div>
  );
};

export const T2Chaos: React.FC = () => {
  return (
    <Scene duration={360} bg={C.sand}>
      <div style={{position: 'absolute', top: 70, left: 120}}>
        <Kicker>La operación, hoy</Kicker>
      </div>
      <AbsoluteFill>
        <div style={{position: 'relative', width: 1400, height: 560, margin: '180px auto 0'}}>
          <Sticky delay={15} x={80} y={40} rot={-5} color="#F6EBB8">¿Quién cubre a la Sra. Pérez el jueves??</Sticky>
          <Sticky delay={35} x={380} y={120} rot={3} color="#F0D9C8">Laura: 2 hrs manejando entre Kendall y Hialeah 🚗</Sticky>
          <Sticky delay={55} x={700} y={30} rot={-2} color="#F6EBB8">Cambiar ruta de PT — otra vez</Sticky>
          <Sticky delay={75} x={1010} y={110} rot={5} color="#E7E0EE">☎ 3 llamadas sin devolver</Sticky>
          <Sticky delay={95} x={220} y={300} rot={4} color="#F0D9C8">Visita de ayer sin documentar (EVV??)</Sticky>
          <Sticky delay={115} x={620} y={280} rot={-4} color="#F6EBB8">Auditoría de Medicare: faltan registros</Sticky>
          <Sticky delay={135} x={960} y={330} rot={2} color="#E7E0EE">Enfermera nueva: ¿por dónde empieza?</Sticky>
        </div>
      </AbsoluteFill>
      <Caption delay={190}>Agendas a mano. Rutas cruzadas. Horas perdidas manejando.</Caption>
    </Scene>
  );
};

// ================= T3 — LA AGENDA QUE SE ARMA SOLA (480f) =================

import mapMiami from './map-miami.jpg';

const PIN_A = [{x: 150, y: 100}, {x: 330, y: 240}, {x: 260, y: 390}, {x: 520, y: 350}];
const PIN_B = [{x: 640, y: 120}, {x: 760, y: 265}, {x: 660, y: 385}];

// rutas "manhattan": tramos horizontales/verticales que siguen la cuadrícula de calles
const routePath = (pts: {x: number; y: number}[]) =>
  pts
    .map((p, i) => {
      if (i === 0) return `M ${p.x} ${p.y}`;
      const prev = pts[i - 1];
      return `L ${prev.x} ${p.y} L ${p.x} ${p.y}`;
    })
    .join(' ');

export const T3Routes: React.FC = () => {
  const frame = useCurrentFrame();
  const mapIn = useFadeUp(10, 40);
  const badge = usePop(300);
  const drawn = interpolate(frame, [120, 250], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const sideIn = useFadeUp(200, 30);
  return (
    <Scene duration={480}>
      <div style={{position: 'absolute', top: 70, left: 120}}>
        <Kicker>Paso 1 — La agenda se arma sola</Kicker>
      </div>
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', paddingBottom: 110}}>
        <div style={{...mapIn, position: 'relative'}}>
          <BrowserFrame url="platform.healthpartnersmedicalgroup.com" style={{width: 1480}}>
            <div style={{display: 'flex', gap: 36, padding: '28px 32px', alignItems: 'flex-start'}}>
          <div style={{width: 880, height: 460, overflow: 'hidden', position: 'relative', borderRadius: 14, border: `1px solid ${C.stone}`, flexShrink: 0}}>
            {/* mapa real: OpenStreetMap (Westchester / Coral Way) tintado a la paleta */}
            {/* eslint-disable-next-line @remotion/warn-native-media-tag */}
            <img src={mapMiami} style={{position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center 45%'}} />
            <svg width="880" height="460" style={{position: 'absolute', inset: 0}}>
              {/* halo blanco bajo las rutas para legibilidad sobre el mapa */}
              <path d={routePath(PIN_A)} stroke="#FFFFFF" strokeWidth="11" fill="none" strokeLinecap="round" strokeLinejoin="round" opacity="0.85"
                strokeDasharray="1400" strokeDashoffset={1400 - drawn * 1400} />
              <path d={routePath(PIN_B)} stroke="#FFFFFF" strokeWidth="11" fill="none" strokeLinecap="round" strokeLinejoin="round" opacity="0.85"
                strokeDasharray="900" strokeDashoffset={900 - drawn * 900} />
              {/* rutas: 2 clínicos, colores fijos de marca */}
              <path d={routePath(PIN_A)} stroke={C.sage} strokeWidth="6" fill="none" strokeLinecap="round" strokeLinejoin="round"
                strokeDasharray="1400" strokeDashoffset={1400 - drawn * 1400} />
              <path d={routePath(PIN_B)} stroke={C.gold} strokeWidth="6" fill="none" strokeLinecap="round" strokeLinejoin="round"
                strokeDasharray="900" strokeDashoffset={900 - drawn * 900} />
              {[...PIN_A, ...PIN_B].map((p, i) => {
                const pop = usePop(40 + i * 14);
                return (
                  <g key={i} style={{...pop, transformOrigin: `${p.x}px ${p.y}px`} as React.CSSProperties}>
                    <circle cx={p.x} cy={p.y} r="16" fill="#FFFFFF" opacity="0.9" />
                    <circle cx={p.x} cy={p.y} r="13" fill={i < 4 ? C.sage : C.gold} />
                    <circle cx={p.x} cy={p.y} r="5.5" fill="#fff" />
                  </g>
                );
              })}
              {/* pulso GPS en la posición actual de cada clínico */}
              <circle cx={PIN_A[0].x} cy={PIN_A[0].y} r={18 + Math.sin(frame * 0.18) * 6} fill="none" stroke={C.sage} strokeWidth="2.5" opacity="0.55" />
              <circle cx={PIN_B[0].x} cy={PIN_B[0].y} r={18 + Math.sin(frame * 0.18 + 2) * 6} fill="none" stroke={C.gold} strokeWidth="2.5" opacity="0.55" />
              {/* etiquetas directas con halo */}
              <text x={PIN_A[0].x + 26} y={PIN_A[0].y - 14} fontFamily="Poppins" fontSize="23" fontWeight="700" fill={C.ink}
                stroke="#FFFFFF" strokeWidth="6" paintOrder="stroke" opacity={drawn > 0.15 ? 1 : 0}>Enf. Laura</text>
              <text x={PIN_B[0].x - 26} y={PIN_B[0].y + 40} fontFamily="Poppins" fontSize="23" fontWeight="700" fill={C.ink} textAnchor="end"
                stroke="#FFFFFF" strokeWidth="6" paintOrder="stroke" opacity={drawn > 0.15 ? 1 : 0}>Enf. Denise</text>
            </svg>
            <div style={{position: 'absolute', right: 10, bottom: 8, fontFamily: F.body, fontSize: 13, color: C.sage, background: 'rgba(250,248,244,0.75)', padding: '2px 8px', borderRadius: 6}}>
              © OpenStreetMap contributors
            </div>
          </div>
              <div style={{...sideIn, display: 'flex', flexDirection: 'column', gap: 14, flex: 1}}>
                <div style={{fontFamily: F.body, fontSize: 21, fontWeight: 700, color: C.sage, letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 4}}>
                  Itinerario — Enf. Laura · hoy
                </div>
                {[
                  ['9:00', 'Carmen R.', 'Enfermería'],
                  ['10:30', 'José D.', 'Enfermería'],
                  ['12:00', 'Ana F.', 'Terapia física'],
                  ['2:00', 'Robert M.', 'Enfermería'],
                ].map(([t, n, s], i) => (
                  <Card key={i} style={{padding: '14px 24px', display: 'flex', alignItems: 'center', gap: 20, background: C.bg}}>
                    <div style={{fontFamily: F.body, fontSize: 23, fontWeight: 700, color: C.gold, width: 78}}>{t}</div>
                    <div>
                      <div style={{fontFamily: F.body, fontSize: 23, fontWeight: 600, color: C.ink}}>{n}</div>
                      <div style={{fontFamily: F.body, fontSize: 18, color: C.sage}}>{s}</div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </BrowserFrame>
          <div style={{...badge, position: 'absolute', top: -40, right: -46, background: C.ink, color: C.bg, borderRadius: 16, padding: '20px 30px', boxShadow: '0 20px 50px rgba(38,37,31,0.25)'}}>
            <div style={{fontFamily: F.display, fontSize: 42, fontWeight: 700}}>+2 visitas</div>
            <div style={{fontFamily: F.body, fontSize: 20, color: C.gold, fontWeight: 600}}>por clínico, por día</div>
          </div>
        </div>
      </AbsoluteFill>
      <Caption delay={330}>Rutas óptimas y continuidad: el mismo equipo rinde más, sin correr más.</Caption>
    </Scene>
  );
};

// ================= T4 — LA VISITA COMPROBADA (360f) =================

export const T4Evv: React.FC = () => {
  const frame = useCurrentFrame();
  const phoneIn = useFadeUp(10, 50);
  const checkin = usePop(80);
  const checkout = usePop(180);
  const stamp = usePop(240);
  return (
    <Scene duration={360} bg={C.sand}>
      <div style={{position: 'absolute', top: 70, left: 120}}>
        <Kicker>Paso 2 — Cada visita, comprobada</Kicker>
      </div>
      <AbsoluteFill style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 100, paddingBottom: 110}}>
        <div style={phoneIn}>
          <div style={{width: 440, height: 700, background: C.ink, borderRadius: 52, padding: 14, boxShadow: '0 30px 80px rgba(38,37,31,0.30)'}}>
            <div style={{width: '100%', height: '100%', background: C.bg, borderRadius: 40, overflow: 'hidden', padding: 26, display: 'flex', flexDirection: 'column', gap: 18}}>
              <div style={{fontFamily: F.body, fontSize: 20, color: C.sage, fontWeight: 600}}>MI DÍA — ENF. LAURA</div>
              <Card style={{padding: '20px 22px'}}>
                <div style={{fontFamily: F.body, fontSize: 23, fontWeight: 700, color: C.ink}}>Carmen Rodríguez</div>
                <div style={{fontFamily: F.body, fontSize: 19, color: C.sage}}>8420 SW 24th St · 9:00 AM</div>
              </Card>
              <div style={checkin}>
                <Card style={{padding: '18px 22px', display: 'flex', alignItems: 'center', gap: 14, background: '#EFF5EF'}}>
                  <div style={{width: 14, height: 14, borderRadius: 7, background: C.green, boxShadow: `0 0 0 ${4 + Math.sin(frame * 0.25) * 3}px ${C.green}33`}} />
                  <div style={{fontFamily: F.body, fontSize: 21, color: C.ink, fontWeight: 600}}>Check-in automático · GPS · 9:02 AM</div>
                </Card>
              </div>
              <div style={checkout}>
                <Card style={{padding: '18px 22px', display: 'flex', alignItems: 'center', gap: 14, background: '#EFF5EF'}}>
                  <Check size={26} />
                  <div style={{fontFamily: F.body, fontSize: 21, color: C.ink, fontWeight: 600}}>Check-out · 9:58 AM · 56 min</div>
                </Card>
              </div>
            </div>
          </div>
        </div>
        <div style={{...stamp, maxWidth: 560}}>
          <Card style={{padding: '40px 46px', display: 'flex', flexDirection: 'column', gap: 18, border: `3px solid ${C.green}`}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 16}}>
              <Check size={42} />
              <div style={{fontFamily: F.display, fontSize: 38, fontWeight: 700, color: C.ink}}>Visita verificada</div>
            </div>
            <div style={{fontFamily: F.body, fontSize: 25, color: C.sage, lineHeight: 1.5}}>
              Quién, dónde, cuándo y por cuánto tiempo — reportado a Medicare (EVV) sin un solo papel.
            </div>
          </Card>
        </div>
      </AbsoluteFill>
      <Caption delay={280}>Cumplimiento automático. Cero papeleo al final del día.</Caption>
    </Scene>
  );
};

// ================= T5 — EL GIRO (240f) =================

export const T5Turn: React.FC = () => {
  const t1 = useFadeUp(20);
  const t2 = useFadeUp(110);
  return (
    <Scene duration={240} bg={C.sage}>
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', gap: 42}}>
        <div style={{...t1, fontFamily: F.body, fontSize: 34, color: C.stone, fontWeight: 500}}>
          La enfermera se va a las 11:40.
        </div>
        <div style={{...t2, fontFamily: F.display, fontSize: 72, color: C.bg, fontWeight: 700, textAlign: 'center', lineHeight: 1.25}}>
          ¿Y entre visitas…
          <br />
          <span style={{color: C.gold}}>quién cuida?</span>
        </div>
      </AbsoluteFill>
    </Scene>
  );
};

// ================= T6 — EL MONITOREO CONTINÚA (480f) =================

const BP = [128, 131, 126, 130, 136, 141, 148]; // sistólica, 7 días

const Packet: React.FC<{x1: number; x2: number; y: number; start: number}> = ({x1, x2, y, start}) => {
  const frame = useCurrentFrame();
  if (frame < start) return null;
  const t = ((frame - start) % 60) / 45;
  if (t > 1) return null;
  const px = x1 + (x2 - x1) * t;
  return (
    <g>
      <circle cx={px} cy={y} r="9" fill={C.gold} opacity="0.9" />
      <circle cx={px - 18} cy={y} r="5" fill={C.gold} opacity="0.4" />
    </g>
  );
};

const LteBadge: React.FC = () => (
  <div style={{display: 'flex', alignItems: 'center', gap: 8, background: '#EFF5EF', borderRadius: 8, padding: '6px 12px', width: 'fit-content'}}>
    <svg width="20" height="16" viewBox="0 0 20 16">
      {[3, 7, 11, 15].map((h, i) => (
        <rect key={i} x={i * 5} y={16 - h} width="3.4" height={h} rx="1" fill={C.green} />
      ))}
    </svg>
    <span style={{fontFamily: F.body, fontSize: 17, fontWeight: 700, color: C.green}}>LTE · sin wifi, sin apps</span>
  </div>
);

export const T6Rpm: React.FC = () => {
  const frame = useCurrentFrame();
  const devIn = useFadeUp(15, 40);
  const cloudIn = usePop(90);
  const dashIn = useFadeUp(130, 30);
  const alertIn = usePop(265);
  const phoneIn = usePop(330);
  const drawn = interpolate(frame, [155, 255], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

  const W = 540, H = 185, PAD = 26;
  const x = (i: number) => PAD + (i * (W - 2 * PAD - 40)) / (BP.length - 1);
  const y = (v: number) => H - PAD - ((v - 118) * (H - 2 * PAD)) / (155 - 118);
  const pts = BP.map((v, i) => `${x(i)},${y(v)}`).join(' ');
  const lastVisible = Math.floor(drawn * (BP.length - 1));
  const CY = 310; // eje vertical de la cadena

  return (
    <Scene duration={480}>
      <div style={{position: 'absolute', top: 60, left: 120}}>
        <Kicker>Paso 3 — El cuidado continúa en casa</Kicker>
      </div>
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', paddingBottom: 96}}>
        <div style={{position: 'relative', width: 1800, height: 620}}>
          {/* conectores + paquetes de datos */}
          <svg width="1800" height="620" style={{position: 'absolute', inset: 0}}>
            <line x1="350" y1={CY} x2="450" y2={CY} stroke={C.stone} strokeWidth="3" strokeDasharray="7 7" />
            <line x1="595" y1={CY} x2="655" y2={CY} stroke={C.stone} strokeWidth="3" strokeDasharray="7 7" />
            <line x1="1310" y1={CY} x2="1430" y2={CY} stroke={C.stone} strokeWidth="3" strokeDasharray="7 7" />
            <Packet x1={350} x2={450} y={CY} start={70} />
            <Packet x1={595} x2={655} y={CY} start={110} />
            <Packet x1={1310} x2={1430} y={CY} start={300} />
          </svg>

          {/* 1 — dispositivo celular en casa */}
          <div style={{...devIn, position: 'absolute', left: 0, top: CY - 120, width: 350}}>
            <Card style={{padding: '24px 28px', display: 'flex', flexDirection: 'column', gap: 12}}>
              <div style={{fontFamily: F.body, fontSize: 18, color: C.sage, fontWeight: 700}}>EN CASA DE CARMEN · 7:15 AM</div>
              <div style={{display: 'flex', alignItems: 'center', gap: 16}}>
                <div style={{fontSize: 44}}>🩺</div>
                <div style={{fontFamily: F.display, fontSize: 46, fontWeight: 700, color: C.ink}}>148/92</div>
              </div>
              <LteBadge />
              <div style={{fontFamily: F.body, fontSize: 17, color: C.sage, lineHeight: 1.4}}>
                Aprieta el botón de siempre — la lectura se envía sola por red celular.
              </div>
            </Card>
            {/* otros signos monitoreables a distancia */}
            <div style={{display: 'flex', flexWrap: 'wrap', gap: 10, marginTop: 14}}>
              {[
                ['❤️', 'Presión', 55],
                ['🩸', 'Glucosa', 385],
                ['⚖️', 'Peso', 400],
                ['🫁', 'Oxígeno', 415],
              ].map(([icon, label, delay], i) => {
                const chip = usePop(delay as number);
                return (
                  <div key={i} style={{...chip, display: 'flex', alignItems: 'center', gap: 8, background: C.white, border: `1px solid ${C.stone}`, borderRadius: 999, padding: '8px 16px', boxShadow: '0 6px 16px rgba(38,37,31,0.08)'}}>
                    <span style={{fontSize: 20}}>{icon}</span>
                    <span style={{fontFamily: F.body, fontSize: 17, fontWeight: 600, color: C.ink}}>{label}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 2 — red celular */}
          <div style={{...cloudIn, position: 'absolute', left: 455, top: CY - 70, width: 140, textAlign: 'center'}}>
            <div style={{width: 120, height: 120, borderRadius: 60, background: C.sand, border: `1px solid ${C.stone}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 52, margin: '0 auto'}}>
              📡
            </div>
            <div style={{fontFamily: F.body, fontSize: 17, color: C.sage, fontWeight: 600, marginTop: 8}}>red celular</div>
          </div>

          {/* 3 — dashboard de la plataforma */}
          <div style={{...dashIn, position: 'absolute', left: 660, top: 30}}>
            <BrowserFrame url="platform.healthpartnersmedicalgroup.com" style={{width: 640}}>
              <div style={{padding: '22px 28px', display: 'flex', flexDirection: 'column', gap: 14}}>
                <div style={{fontFamily: F.body, fontSize: 19, color: C.sage, fontWeight: 700, letterSpacing: 1}}>
                  MONITOREO REMOTO — CARMEN R. · PRESIÓN SISTÓLICA, 7 DÍAS
                </div>
                <svg width={W} height={H}>
                  {[125, 140, 155].map((v) => (
                    <g key={v}>
                      <line x1={PAD} y1={y(v)} x2={W - PAD - 30} y2={y(v)} stroke={C.stone} strokeWidth="1" strokeDasharray={v === 140 ? '6 5' : undefined} opacity={v === 140 ? 0.9 : 0.5} />
                      <text x={W - PAD - 24} y={y(v) + 5} fontFamily="Poppins" fontSize="14" fill={C.sage}>{v}</text>
                    </g>
                  ))}
                  <polyline points={pts} fill="none" stroke={C.sage} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"
                    strokeDasharray="800" strokeDashoffset={800 - drawn * 800} />
                  {BP.map((v, i) =>
                    i <= lastVisible ? <circle key={i} cx={x(i)} cy={y(v)} r={i === BP.length - 1 ? 6.5 : 4} fill={C.sage} stroke="#fff" strokeWidth="2" /> : null
                  )}
                  {drawn >= 1 && (
                    <text x={x(6) - 10} y={y(148) - 14} fontFamily="Poppins" fontSize="19" fontWeight="700" fill={C.ink} textAnchor="end">148/92</text>
                  )}
                </svg>
                <div style={alertIn}>
                  <div style={{border: `2.5px solid ${C.red}`, borderRadius: 12, padding: '14px 20px', display: 'flex', gap: 14, alignItems: 'center'}}>
                    <div style={{fontSize: 28}}>⚠️</div>
                    <div>
                      <div style={{fontFamily: F.body, fontSize: 21, fontWeight: 700, color: C.red}}>Presión elevada — 3 días subiendo</div>
                      <div style={{fontFamily: F.body, fontSize: 17, color: C.sage}}>Regla: sistólica &gt;140 × 3 días → alertar a enfermera a cargo</div>
                    </div>
                  </div>
                </div>
              </div>
            </BrowserFrame>
          </div>

          {/* 4 — teléfono de la enfermera a cargo */}
          <div style={{...phoneIn, position: 'absolute', left: 1435, top: 75, width: 320, textAlign: 'center'}}>
            <div style={{width: 300, height: 440, background: C.ink, borderRadius: 40, padding: 11, margin: '0 auto', boxShadow: '0 24px 60px rgba(38,37,31,0.28)'}}>
              <div style={{width: '100%', height: '100%', background: '#EDEAE3', borderRadius: 31, overflow: 'hidden', display: 'flex', flexDirection: 'column', paddingTop: 40, gap: 10}}>
                <div style={{fontFamily: F.body, fontSize: 15, color: C.sage}}>9:07 AM</div>
                <div style={{margin: '0 14px', background: '#FFFFFF', borderRadius: 16, padding: '14px 16px', textAlign: 'left', boxShadow: '0 8px 22px rgba(38,37,31,0.14)'}}>
                  <div style={{display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6}}>
                    <div style={{width: 18, height: 18, borderRadius: 5, background: C.sage}} />
                    <span style={{fontFamily: F.body, fontSize: 14, color: C.sage, fontWeight: 600}}>HEALTH PARTNERS · ahora</span>
                  </div>
                  <div style={{fontFamily: F.body, fontSize: 18, fontWeight: 700, color: C.ink, lineHeight: 1.3}}>
                    ⚠️ Carmen R. — presión elevada 148/92
                  </div>
                  <div style={{fontFamily: F.body, fontSize: 16, color: C.sage, marginTop: 4}}>Acción sugerida: llamar hoy</div>
                </div>
              </div>
            </div>
            <div style={{fontFamily: F.body, fontSize: 18, color: C.sage, fontWeight: 600, marginTop: 10}}>Enf. Laura — a cargo de Carmen</div>
          </div>
        </div>
      </AbsoluteFill>
      <Caption delay={380}>Presión, glucosa, peso y oxígeno — del paciente al teléfono de su enfermera, sin que nadie configure nada.</Caption>
    </Scene>
  );
};

// ================= T7 — Y MEDICARE LO PAGA (420f) =================

const fmt = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

export const T7Billing: React.FC = () => {
  const frame = useCurrentFrame();
  const ringIn = useFadeUp(15, 40);
  const secs = interpolate(frame, [40, 220], [512, 1300], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const prog = Math.min(secs / 1200, 1);
  const billable = secs >= 1200;
  const badge = usePop(210);
  const revIn = useFadeUp(260, 30);
  const revenue = Math.round(interpolate(frame, [280, 380], [0, 8400], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}));
  const R = 120, CIRC = 2 * Math.PI * R;

  return (
    <Scene duration={420} bg={C.sand}>
      <div style={{position: 'absolute', top: 70, left: 120}}>
        <Kicker>Paso 4 — Y Medicare lo paga</Kicker>
      </div>
      <AbsoluteFill style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 100, paddingBottom: 110}}>
        <div style={{...ringIn, position: 'relative', width: 340, height: 340}}>
          <svg width="340" height="340">
            <circle cx="170" cy="170" r={R} stroke={C.stone} strokeWidth="16" fill="none" />
            <circle
              cx="170" cy="170" r={R}
              stroke={billable ? C.green : C.gold}
              strokeWidth="16"
              fill="none"
              strokeLinecap="round"
              strokeDasharray={CIRC}
              strokeDashoffset={CIRC * (1 - prog)}
              transform="rotate(-90 170 170)"
            />
          </svg>
          <div style={{position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', gap: 4}}>
            <div style={{fontFamily: F.display, fontSize: 64, fontWeight: 700, color: C.ink}}>{fmt(secs)}</div>
            <div style={{fontFamily: F.body, fontSize: 15, color: C.sage, fontWeight: 600, textAlign: 'center', maxWidth: 170, lineHeight: 1.4}}>
              MIN. DE CUIDADO
              <br />
              ESTE MES · CARMEN R.
            </div>
          </div>
        </div>
        <div style={{display: 'flex', flexDirection: 'column', gap: 28, width: 620}}>
          <div style={badge}>
            <Card style={{padding: '26px 34px', display: 'flex', alignItems: 'center', gap: 18, border: `3px solid ${C.green}`}}>
              <Check size={38} />
              <div>
                <div style={{fontFamily: F.body, fontSize: 27, fontWeight: 700, color: C.ink}}>20 minutos alcanzados — facturable</div>
                <div style={{fontFamily: F.body, fontSize: 21, color: C.sage}}>Chronic Care Management · CPT 99490 · documentado y auditable</div>
              </div>
            </Card>
          </div>
          <div style={revIn}>
            <div style={{background: C.ink, borderRadius: 18, padding: '30px 38px', boxShadow: '0 24px 60px rgba(38,37,31,0.25)'}}>
              <div style={{fontFamily: F.body, fontSize: 20, letterSpacing: 2, textTransform: 'uppercase', color: C.gold, fontWeight: 700}}>
                Ingreso nuevo este mes
              </div>
              <div style={{fontFamily: F.display, fontSize: 66, fontWeight: 700, color: C.bg}}>
                ${revenue.toLocaleString('en-US')}
              </div>
              <div style={{fontFamily: F.body, fontSize: 21, color: C.stone}}>70 pacientes inscritos · sin una visita extra</div>
            </div>
          </div>
        </div>
      </AbsoluteFill>
      <Caption delay={320}>Cada minuto de cuidado, contado, documentado — y cobrado.</Caption>
    </Scene>
  );
};

// ================= T8 — CIERRE (270f) =================

export const T8Close: React.FC = () => {
  const t1 = useFadeUp(15);
  const t2 = useFadeUp(70);
  const t3 = useFadeUp(120);
  const t4 = useFadeUp(170);
  return (
    <Scene duration={270} bg="#000000">
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', gap: 40}}>
        <div style={{...t1, fontFamily: F.display, fontSize: 56, color: '#FFFFFF', fontWeight: 700, textAlign: 'center', lineHeight: 1.3}}>
          Más visitas. Cero papeleo.
          <br />
          Pacientes vigilados 24/7.
        </div>
        <div style={{...t2, fontFamily: F.display, fontSize: 44, color: C.gold, fontWeight: 700}}>
          Y Medicare lo paga.
        </div>
        <div style={{...t3, marginTop: 34, display: 'flex', alignItems: 'center', gap: 44}}>
          <YhpLogo width={460} />
          <div style={{width: 1, height: 64, background: '#4A4A4A'}} />
          <BorsogaLogo width={310} />
        </div>
        <div style={{...t4, fontFamily: F.body, fontSize: 24, color: '#FFFFFF', letterSpacing: 5, textTransform: 'uppercase', fontWeight: 500}}>
          Veámoslo en vivo
        </div>
      </AbsoluteFill>
    </Scene>
  );
};
