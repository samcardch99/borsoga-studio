import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {C, F} from './theme';
import {
  Scene, Kicker, Caption, GoldRule, Card, Pill, Check, Spinner, BrowserFrame, Logo,
  useFadeUp, usePop, typed,
} from './ui';

// ================= S1 — INTRO (180f) =================

import logoYhp from './logo-yhp.png';

const YhpLogo: React.FC<{width?: number}> = ({width = 620}) => (
  // eslint-disable-next-line @remotion/warn-native-media-tag
  <img src={logoYhp} style={{width, height: 'auto', display: 'block'}} />
);

export const S1Intro: React.FC = () => {
  const t1 = useFadeUp(10);
  const t2 = useFadeUp(35);
  const t3 = useFadeUp(65);
  return (
    <Scene duration={180}>
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', gap: 34}}>
        <div style={t1}><YhpLogo width={640} /></div>
        <GoldRule delay={25} width={160} />
        <div style={{...t2, fontFamily: F.display, fontSize: 76, color: C.ink, fontWeight: 600, textAlign: 'center', maxWidth: 1400, lineHeight: 1.15}}>
          ¿Y si cada referido se respondiera
          <br />
          en <span style={{color: C.gold}}>minutos</span>, no en horas?
        </div>
        <div style={{...t3, fontFamily: F.body, fontSize: 30, color: C.sage}}>
          Una demostración de 90 segundos
        </div>
      </AbsoluteFill>
    </Scene>
  );
};

// ================= S2 — FAX → REFERIDO (540f) =================

const FaxLine: React.FC<{w: number | string; bold?: boolean; text?: string}> = ({w, bold, text}) =>
  text ? (
    <div style={{fontFamily: 'monospace', fontSize: bold ? 24 : 20, color: bold ? C.ink : '#6b675d', fontWeight: bold ? 700 : 400}}>
      {text}
    </div>
  ) : (
    <div style={{height: 12, width: w as number, backgroundColor: '#E4E0D6', borderRadius: 4}} />
  );

const Field: React.FC<{label: string; value: string; delay: number}> = ({label, value, delay}) => {
  const frame = useCurrentFrame();
  const st = useFadeUp(delay, 18);
  const v = typed(value, frame, delay + 6, 1.4);
  return (
    <div style={{...st, display: 'flex', flexDirection: 'column', gap: 6}}>
      <div style={{fontFamily: F.body, fontSize: 20, color: C.sage, letterSpacing: 1, textTransform: 'uppercase', fontWeight: 600}}>
        {label}
      </div>
      <div style={{display: 'flex', alignItems: 'center', gap: 12}}>
        <div style={{fontFamily: F.body, fontSize: 30, color: C.ink, fontWeight: 500, minHeight: 38}}>{v}</div>
        {frame > delay + 6 + value.length / 1.4 && <Check size={26} />}
      </div>
    </div>
  );
};

import faxScan from './fax-scan.jpg';

export const S2Fax: React.FC = () => {
  const frame = useCurrentFrame();
  const faxIn = useFadeUp(15, 60);
  const scanY = interpolate(frame, [60, 150], [0, 560], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const showScan = frame >= 60 && frame <= 150;
  const cardIn = useFadeUp(140, 40);
  const arrow = usePop(120);

  return (
    <Scene duration={540}>
      <div style={{position: 'absolute', top: 70, left: 120}}>
        <Kicker>Paso 1 — Recepción del referido</Kicker>
      </div>
      <AbsoluteFill style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 90, paddingBottom: 120}}>
        {/* fax document — escaneo real */}
        <div style={{...faxIn, position: 'relative'}}>
          <div style={{width: 480, height: 600, borderRadius: 6, overflow: 'hidden', boxShadow: '0 24px 60px rgba(38,37,31,0.18)', border: `1px solid ${C.stone}`, background: '#fff'}}>
            {/* eslint-disable-next-line @remotion/warn-native-media-tag */}
            <img src={faxScan} style={{width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'top'}} />
          </div>
          {showScan && (
            <div
              style={{
                position: 'absolute',
                top: scanY + 20,
                left: 0,
                right: 0,
                height: 4,
                background: C.gold,
                boxShadow: `0 0 24px 6px ${C.gold}66`,
                borderRadius: 2,
              }}
            />
          )}
          <div style={{position: 'absolute', top: -28, left: 0, fontFamily: F.body, fontSize: 22, color: C.sage}}>
            Fax entrante · 2:47 PM
          </div>
        </div>

        {/* arrow */}
        <div style={{...arrow, fontFamily: F.body, fontSize: 30, color: C.gold, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8}}>
          <svg width="90" height="40" viewBox="0 0 90 40">
            <path d="M4 20h72M64 8l14 12-14 12" stroke={C.gold} strokeWidth="4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span style={{fontSize: 22, fontWeight: 600}}>IA</span>
        </div>

        {/* extracted referral */}
        <div style={cardIn}>
          <Card style={{width: 640, padding: '44px 52px', display: 'flex', flexDirection: 'column', gap: 30}}>
            <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
              <div style={{fontFamily: F.display, fontSize: 34, color: C.ink, fontWeight: 600}}>Referido nuevo</div>
              <Pill color={C.white} bg={C.gold}>Auto-creado</Pill>
            </div>
            <div style={{height: 1, background: C.stone}} />
            <Field label="Paciente" value="Carmen Rodríguez, 79" delay={170} />
            <Field label="Diagnóstico" value="Insuf. cardíaca · Diabetes tipo 2" delay={215} />
            <Field label="Seguro" value="Medicare Parte A/B" delay={270} />
            <Field label="Servicios" value="Enfermería + Terapia física" delay={315} />
            <Field label="Alta hospitalaria" value="Hoy, 4:00 PM" delay={360} />
          </Card>
        </div>
      </AbsoluteFill>
      <Caption delay={420}>El fax del hospital se convierte en referido — solo, en segundos.</Caption>
    </Scene>
  );
};

// ================= S2b — MULTI-CANAL (330f) =================

const Channel: React.FC<{delay: number; icon: string; label: string; sub: string}> = ({delay, icon, label, sub}) => {
  const st = usePop(delay);
  return (
    <div style={st}>
      <Card style={{width: 270, padding: '30px 24px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10}}>
        <div style={{fontSize: 54}}>{icon}</div>
        <div style={{fontFamily: F.body, fontSize: 27, fontWeight: 700, color: C.ink}}>{label}</div>
        <div style={{fontFamily: F.body, fontSize: 19, color: C.sage, textAlign: 'center', lineHeight: 1.35}}>{sub}</div>
      </Card>
    </div>
  );
};

export const S2bChannels: React.FC = () => {
  const frame = useCurrentFrame();
  const queueIn = usePop(130);
  const landed = [150, 165, 180, 195].filter((t) => frame >= t).length;
  const lineH = interpolate(frame, [125, 155], [0, 74], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <Scene duration={330}>
      <div style={{position: 'absolute', top: 70, left: 120}}>
        <Kicker>Venga por donde venga</Kicker>
      </div>
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', paddingBottom: 110, gap: 0}}>
        <div style={{display: 'flex', gap: 34}}>
          <Channel delay={20} icon="📠" label="Fax" sub="del hospital" />
          <Channel delay={45} icon="✉️" label="Email" sub="del consultorio" />
          <Channel delay={70} icon="💻" label="Web" sub="formulario de referidos" />
          <Channel delay={95} icon="📞" label="Teléfono" sub="registrado en 30 seg." />
        </div>
        <svg width="900" height="80" viewBox="0 0 900 80" style={{display: 'block'}}>
          {[135, 345, 555, 765].map((x, i) => (
            <path key={i} d={`M ${x} 0 C ${x} 45, 450 30, 450 ${lineH}`} stroke={C.gold} strokeWidth="3.5" fill="none" opacity={frame > 125 ? 0.9 : 0} />
          ))}
        </svg>
        <div style={queueIn}>
          <div style={{background: C.ink, borderRadius: 18, padding: '26px 46px', display: 'flex', alignItems: 'center', gap: 26, boxShadow: '0 24px 60px rgba(38,37,31,0.25)'}}>
            <div style={{fontFamily: F.body, fontSize: 28, fontWeight: 700, color: C.bg}}>Una sola cola de referidos</div>
            <div style={{fontFamily: F.body, fontSize: 26, fontWeight: 700, color: C.ink, background: C.gold, borderRadius: 999, padding: '6px 22px'}}>
              {landed} nuevos
            </div>
          </div>
        </div>
      </AbsoluteFill>
      <Caption delay={210}>Fax, email, web o llamada: todo cae en el mismo lugar, con el mismo cronómetro.</Caption>
    </Scene>
  );
};

// ================= S3 — ELEGIBILIDAD (360f) =================

export const S3Eligibility: React.FC = () => {
  const frame = useCurrentFrame();
  const cardIn = useFadeUp(10, 40);
  const btnPress = frame >= 70 && frame < 80;
  const checking = frame >= 80 && frame < 170;
  const done = frame >= 170;
  const resultIn = usePop(170);

  return (
    <Scene duration={360} bg={C.sand}>
      <div style={{position: 'absolute', top: 70, left: 120}}>
        <Kicker>Paso 2 — Verificación de cobertura</Kicker>
      </div>
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', paddingBottom: 120}}>
        <div style={cardIn}>
          <Card style={{width: 860, padding: '50px 60px', display: 'flex', flexDirection: 'column', gap: 34}}>
            <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'baseline'}}>
              <div style={{fontFamily: F.display, fontSize: 36, color: C.ink, fontWeight: 600}}>Carmen Rodríguez</div>
              <div style={{fontFamily: F.body, fontSize: 24, color: C.sage}}>Medicare ID ****-4821</div>
            </div>
            <div style={{height: 1, background: C.stone}} />
            <div style={{display: 'flex', alignItems: 'center', gap: 28}}>
              <div
                style={{
                  fontFamily: F.body,
                  fontSize: 26,
                  fontWeight: 600,
                  color: C.bg,
                  background: C.sage,
                  padding: '18px 40px',
                  borderRadius: 12,
                  transform: btnPress ? 'scale(0.95)' : 'scale(1)',
                }}
              >
                Verificar elegibilidad
              </div>
              {checking && (
                <div style={{display: 'flex', alignItems: 'center', gap: 14}}>
                  <Spinner />
                  <span style={{fontFamily: F.body, fontSize: 24, color: C.sage}}>Consultando a Medicare…</span>
                </div>
              )}
            </div>
            {done && (
              <div style={{...resultIn, display: 'flex', flexDirection: 'column', gap: 18, background: '#EFF5EF', border: `1px solid ${C.green}44`, borderRadius: 14, padding: '28px 34px'}}>
                <div style={{display: 'flex', alignItems: 'center', gap: 16}}>
                  <Check size={38} />
                  <span style={{fontFamily: F.body, fontSize: 32, fontWeight: 700, color: C.green}}>Cobertura activa — elegible para home health</span>
                </div>
                <div style={{fontFamily: F.body, fontSize: 24, color: C.sage, lineHeight: 1.5}}>
                  Medicare Parte A y B · Sin deducible pendiente · Enfermería y terapia física cubiertas
                </div>
              </div>
            )}
          </Card>
        </div>
      </AbsoluteFill>
      <Caption delay={220}>Cobertura verificada en 5 segundos. Sin llamadas, sin esperas.</Caption>
    </Scene>
  );
};

// ================= S4 — COLA / SLA (450f) =================

const Row: React.FC<{
  delay: number; name: string; hosp: string; ins: string; time: string;
  status: 'new' | 'accepted'; flip?: number;
}> = ({delay, name, hosp, ins, time, status, flip}) => {
  const frame = useCurrentFrame();
  const st = useFadeUp(delay, 20);
  const flipped = flip !== undefined && frame >= flip;
  const s = flipped ? 'accepted' : status;
  return (
    <div style={{...st, display: 'grid', gridTemplateColumns: '1.5fr 1.4fr 1fr 0.9fr 0.9fr', alignItems: 'center', padding: '22px 36px', borderBottom: `1px solid ${C.sand}`, background: flipped ? '#F4F7F4' : C.white}}>
      <div style={{fontFamily: F.body, fontSize: 26, fontWeight: 600, color: C.ink}}>{name}</div>
      <div style={{fontFamily: F.body, fontSize: 24, color: C.sage}}>{hosp}</div>
      <div style={{fontFamily: F.body, fontSize: 24, color: C.sage}}>{ins}</div>
      <div>
        {s === 'new' ? (
          <Pill color={C.ink} bg={C.sand}>Nuevo</Pill>
        ) : (
          <Pill color={C.white} bg={C.green}>Aceptado</Pill>
        )}
      </div>
      <div style={{fontFamily: F.body, fontSize: 24, color: C.gold, fontWeight: 700, textAlign: 'right'}}>{time}</div>
    </div>
  );
};

export const S4Queue: React.FC = () => {
  const browserIn = useFadeUp(10, 50);
  const chipIn = usePop(230);
  return (
    <Scene duration={450}>
      <div style={{position: 'absolute', top: 70, left: 120}}>
        <Kicker>Paso 3 — Todo bajo control</Kicker>
      </div>
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', paddingBottom: 120}}>
        <div style={{...browserIn, position: 'relative'}}>
          <BrowserFrame url="referidos.healthpartnersmedicalgroup.com" style={{width: 1400}}>
            <div style={{padding: '34px 0 10px'}}>
              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0 36px 24px'}}>
                <div style={{fontFamily: F.display, fontSize: 34, fontWeight: 600, color: C.ink}}>Cola de referidos — hoy</div>
                <div style={{fontFamily: F.body, fontSize: 22, color: C.sage}}>Lunes, 2:52 PM</div>
              </div>
              <div style={{display: 'grid', gridTemplateColumns: '1.5fr 1.4fr 1fr 0.9fr 0.9fr', padding: '0 36px 14px', fontFamily: F.body, fontSize: 20, color: C.sage, letterSpacing: 1, textTransform: 'uppercase', fontWeight: 600}}>
                <div>Paciente</div><div>Hospital</div><div>Seguro</div><div>Estado</div><div style={{textAlign: 'right'}}>Respuesta</div>
              </div>
              <Row delay={60} name="Carmen Rodríguez" hosp="Memorial Hospital" ins="Medicare" time="4 min" status="new" flip={180} />
              <Row delay={90} name="José Delgado" hosp="St. Mary Medical" ins="Medicare Adv." time="11 min" status="accepted" />
              <Row delay={120} name="Ana Fuentes" hosp="Baptist Health" ins="Medicare" time="9 min" status="accepted" />
              <Row delay={150} name="Robert Miller" hosp="Memorial Hospital" ins="Medicaid" time="16 min" status="accepted" />
            </div>
          </BrowserFrame>
          <div style={{...chipIn, position: 'absolute', top: -40, right: -60, background: C.ink, color: C.bg, borderRadius: 16, padding: '22px 34px', boxShadow: '0 20px 50px rgba(38,37,31,0.25)'}}>
            <div style={{fontFamily: F.body, fontSize: 20, letterSpacing: 2, textTransform: 'uppercase', color: C.gold, fontWeight: 700}}>Respuesta promedio</div>
            <div style={{fontFamily: F.display, fontSize: 56, fontWeight: 600}}>12 minutos</div>
          </div>
        </div>
      </AbsoluteFill>
      <Caption delay={280}>El hospital recibe la confirmación al instante. La agencia que responde primero, gana el paciente.</Caption>
    </Scene>
  );
};

// ================= S5 — SMS FAMILIA (450f) =================

const Bubble: React.FC<{delay: number; children: React.ReactNode; accent?: boolean}> = ({delay, children, accent}) => {
  const st = usePop(delay);
  return (
    <div
      style={{
        ...st,
        alignSelf: 'flex-start',
        maxWidth: 420,
        background: accent ? C.sage : '#E9E9EB',
        color: accent ? C.bg : C.ink,
        borderRadius: 24,
        borderTopLeftRadius: 8,
        padding: '20px 24px',
        fontFamily: F.body,
        fontSize: 24,
        lineHeight: 1.45,
        transformOrigin: 'left bottom',
      }}
    >
      {children}
    </div>
  );
};

export const S5Family: React.FC = () => {
  const phoneIn = useFadeUp(10, 60);
  const sideIn = useFadeUp(200, 30);
  return (
    <Scene duration={450} bg={C.sand}>
      <div style={{position: 'absolute', top: 70, left: 120}}>
        <Kicker>Paso 4 — La familia, tranquila</Kicker>
      </div>
      <AbsoluteFill style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 110, paddingBottom: 120}}>
        <div style={phoneIn}>
          <div style={{width: 480, height: 760, background: C.ink, borderRadius: 56, padding: 16, boxShadow: '0 30px 80px rgba(38,37,31,0.30)'}}>
            <div style={{width: '100%', height: '100%', background: C.white, borderRadius: 44, overflow: 'hidden', display: 'flex', flexDirection: 'column'}}>
              <div style={{background: '#F6F6F6', padding: '26px 0 16px', textAlign: 'center', borderBottom: '1px solid #E3E3E3'}}>
                <div style={{fontFamily: F.body, fontSize: 22, fontWeight: 600, color: C.ink}}>Your Health Partners</div>
                <div style={{fontFamily: F.body, fontSize: 17, color: '#8A877E'}}>Mensaje de texto</div>
              </div>
              <div style={{flex: 1, padding: 24, display: 'flex', flexDirection: 'column', gap: 18}}>
                <Bubble delay={70} accent>
                  Hola María 👋 Hoy visitamos a su mamá. Presión estable (128/82), se siente bien de ánimo. Próxima visita: jueves 10 AM. — Enf. Laura, YHP
                </Bubble>
                <Bubble delay={230}>
                  Gracias!! Qué alivio saberlo, yo estoy en Nueva York 🙏
                </Bubble>
                <Bubble delay={320} accent>
                  Para servirle siempre. ¿Nos regala una reseña? ⭐⭐⭐⭐⭐ g.page/yhp-review
                </Bubble>
              </div>
            </div>
          </div>
        </div>
        <div style={{...sideIn, display: 'flex', flexDirection: 'column', gap: 30, maxWidth: 560}}>
          <div style={{fontFamily: F.display, fontSize: 52, color: C.ink, fontWeight: 600, lineHeight: 1.2}}>
            Reporte automático
            <br />
            después de cada visita
          </div>
          <GoldRule delay={230} width={110} />
          <div style={{fontFamily: F.body, fontSize: 28, color: C.sage, lineHeight: 1.55}}>
            Bilingüe, en el idioma de cada familia. Y cada visita feliz se convierte en una reseña de Google — 2 a 4 nuevas por semana, en piloto automático.
          </div>
        </div>
      </AbsoluteFill>
      <Caption delay={340}>La hija que vive lejos, informada. La reputación, creciendo sola.</Caption>
    </Scene>
  );
};

// ================= S6 — CIERRE (360f) =================

import logoBorsoga from './logo-borsoga.svg';

const BorsogaLogo: React.FC<{width?: number}> = ({width = 520}) => (
  // eslint-disable-next-line @remotion/warn-native-media-tag
  <img src={logoBorsoga} style={{width, height: 'auto', display: 'block'}} />
);

export const S6Close: React.FC = () => {
  const t1 = useFadeUp(15);
  const t2 = useFadeUp(80);
  const t3 = useFadeUp(140);
  const t4 = useFadeUp(190);
  return (
    <Scene duration={360} bg="#000000">
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', gap: 44}}>
        <div style={{...t1, fontFamily: F.display, fontSize: 60, color: '#FFFFFF', fontWeight: 700, textAlign: 'center', lineHeight: 1.3}}>
          Más referidos. Familias tranquilas.
          <br />
          Cero fricción.
        </div>
        <div style={{...t2, fontFamily: F.body, fontSize: 27, color: '#9A9A9A', textAlign: 'center', lineHeight: 1.5}}>
          Referidos en minutos · Cobertura verificada al instante · Familias informadas · Reseñas en automático
        </div>
        <div style={{...t3, marginTop: 48, display: 'flex', alignItems: 'center', gap: 44}}>
          <YhpLogo width={460} />
          <div style={{width: 1, height: 64, background: '#4A4A4A'}} />
          <BorsogaLogo width={310} />
        </div>
        <div style={{...t4, fontFamily: F.body, fontSize: 24, color: '#FFFFFF', letterSpacing: 5, textTransform: 'uppercase', fontWeight: 500}}>
          Veámoslo en vivo
        </div>
      </AbsoluteFill>
    </Scene>
  );
};
