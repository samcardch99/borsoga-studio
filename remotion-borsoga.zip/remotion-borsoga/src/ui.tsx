import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig, AbsoluteFill} from 'remotion';
import {C, F} from './theme';

// ---------- animation helpers ----------

export const useFadeUp = (delay: number, dist = 40) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - delay, fps, config: {damping: 200, stiffness: 80}});
  return {
    opacity: s,
    transform: `translateY(${(1 - s) * dist}px)`,
  } as React.CSSProperties;
};

export const usePop = (delay: number) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - delay, fps, config: {damping: 14, stiffness: 160, mass: 0.6}});
  return {
    opacity: frame < delay ? 0 : 1,
    transform: `scale(${s})`,
  } as React.CSSProperties;
};

export const typed = (text: string, frame: number, delay: number, cps = 1.2) => {
  const n = Math.max(0, Math.floor((frame - delay) * cps));
  return text.slice(0, n);
};

// ---------- scene wrapper with fade in/out ----------

export const Scene: React.FC<{
  duration: number;
  children: React.ReactNode;
  bg?: string;
}> = ({duration, children, bg = C.bg}) => {
  const frame = useCurrentFrame();
  const opacity = interpolate(
    frame,
    [0, 15, duration - 15, duration],
    [0, 1, 1, 0],
    {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}
  );
  return (
    <AbsoluteFill style={{backgroundColor: bg, opacity}}>
      {children}
    </AbsoluteFill>
  );
};

// ---------- brand atoms ----------

export const Kicker: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
  <div
    style={{
      fontFamily: F.body,
      fontSize: 26,
      letterSpacing: 6,
      textTransform: 'uppercase',
      color: C.gold,
      fontWeight: 600,
      ...style,
    }}
  >
    {children}
  </div>
);

export const Caption: React.FC<{delay?: number; children: React.ReactNode}> = ({delay = 20, children}) => {
  const st = useFadeUp(delay, 24);
  return (
    <div
      style={{
        position: 'absolute',
        bottom: 70,
        left: 0,
        right: 0,
        display: 'flex',
        justifyContent: 'center',
        ...st,
      }}
    >
      <div
        style={{
          fontFamily: F.display,
          fontSize: 44,
          color: C.ink,
          textAlign: 'center',
          maxWidth: 1300,
          lineHeight: 1.25,
          fontWeight: 600,
        }}
      >
        {children}
      </div>
    </div>
  );
};

export const GoldRule: React.FC<{delay?: number; width?: number}> = ({delay = 0, width = 120}) => {
  const frame = useCurrentFrame();
  const w = interpolate(frame, [delay, delay + 25], [0, width], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  return <div style={{height: 3, width: w, backgroundColor: C.gold, borderRadius: 2}} />;
};

export const Card: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
  <div
    style={{
      backgroundColor: C.white,
      borderRadius: 20,
      boxShadow: '0 24px 60px rgba(38,37,31,0.10)',
      border: `1px solid ${C.stone}`,
      ...style,
    }}
  >
    {children}
  </div>
);

export const Pill: React.FC<{color: string; bg: string; children: React.ReactNode; style?: React.CSSProperties}> = ({
  color,
  bg,
  children,
  style,
}) => (
  <span
    style={{
      fontFamily: F.body,
      fontSize: 22,
      fontWeight: 600,
      color,
      backgroundColor: bg,
      padding: '8px 20px',
      borderRadius: 999,
      whiteSpace: 'nowrap',
      ...style,
    }}
  >
    {children}
  </span>
);

export const Check: React.FC<{size?: number; color?: string}> = ({size = 30, color = C.green}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
    <circle cx="12" cy="12" r="11" fill={color} />
    <path d="M7 12.5l3.2 3.2L17 9" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const Spinner: React.FC<{size?: number}> = ({size = 34}) => {
  const frame = useCurrentFrame();
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      style={{transform: `rotate(${frame * 14}deg)`}}
    >
      <circle cx="12" cy="12" r="9" stroke={C.stone} strokeWidth="3" fill="none" />
      <path d="M12 3a9 9 0 0 1 9 9" stroke={C.gold} strokeWidth="3" fill="none" strokeLinecap="round" />
    </svg>
  );
};

export const BrowserFrame: React.FC<{children: React.ReactNode; url: string; style?: React.CSSProperties}> = ({
  children,
  url,
  style,
}) => (
  <Card style={{overflow: 'hidden', ...style}}>
    <div
      style={{
        height: 56,
        backgroundColor: C.sand,
        display: 'flex',
        alignItems: 'center',
        padding: '0 24px',
        gap: 10,
        borderBottom: `1px solid ${C.stone}`,
      }}
    >
      <div style={{width: 14, height: 14, borderRadius: 7, background: '#E0AFA0'}} />
      <div style={{width: 14, height: 14, borderRadius: 7, background: '#E5CFA3'}} />
      <div style={{width: 14, height: 14, borderRadius: 7, background: '#B5C4B1'}} />
      <div
        style={{
          marginLeft: 20,
          fontFamily: F.body,
          fontSize: 20,
          color: C.sage,
          background: C.bg,
          borderRadius: 8,
          padding: '6px 18px',
          flex: 1,
        }}
      >
        {url}
      </div>
    </div>
    {children}
  </Card>
);

export const Logo: React.FC<{size?: number; light?: boolean}> = ({size = 40, light}) => (
  <div style={{display: 'flex', alignItems: 'baseline', gap: 14}}>
    <span style={{fontFamily: F.display, fontSize: size, fontWeight: 600, color: light ? C.bg : C.ink}}>
      Your Health Partners
    </span>
    <span style={{fontFamily: F.body, fontSize: size * 0.45, color: C.gold, fontWeight: 600, letterSpacing: 2}}>
      MEDICAL GROUP
    </span>
  </div>
);
