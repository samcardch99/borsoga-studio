import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Scene, useFadeUp, usePop} from './ui';
import logoBorsoga from './logo-borsoga.svg';
import borsogaStack from './borsoga-stack.png';
import ddcSeal from './app/ddc-seal.png';
import imgHome from './app/home.png';
import imgCatalogo from './app/catalogo.png';
import imgDetalle from './app/detalle.png';
import imgDetalle2 from './app/detalle2.png';
import imgInvertir from './app/invertir.png';
import imgNosotros from './app/nosotros.png';
import imgPortal from './app/portal.png';
import imgObra from './app/obra.png';
import imgAr from './app/ar.png';
import imgDash from './app/dash.png';

// —— identidad DDC ——
const D = {
  ink: '#0F1931',
  navy: '#162D57',
  gray: '#BBBFC7',
  light: '#DDE0E2',
  white: '#FFFFFF',
};
const FJ = "'Jost', sans-serif";

const DKicker: React.FC<{children: React.ReactNode}> = ({children}) => (
  <div style={{fontFamily: FJ, fontSize: 26, letterSpacing: 6, textTransform: 'uppercase', color: D.gray, fontWeight: 600}}>
    {children}
  </div>
);

const DCaption: React.FC<{delay?: number; children: React.ReactNode}> = ({delay = 20, children}) => {
  const st = useFadeUp(delay, 24);
  return (
    <div style={{position: 'absolute', bottom: 64, left: 0, right: 0, display: 'flex', justifyContent: 'center', ...st}}>
      <div style={{fontFamily: FJ, fontSize: 42, color: D.white, textAlign: 'center', maxWidth: 1350, lineHeight: 1.3, fontWeight: 500}}>
        {children}
      </div>
    </div>
  );
};

const GrayRule: React.FC<{delay?: number; width?: number}> = ({delay = 0, width = 130}) => {
  const frame = useCurrentFrame();
  const w = interpolate(frame, [delay, delay + 25], [0, width], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return <div style={{height: 2.5, width: w, backgroundColor: D.gray, borderRadius: 2}} />;
};

// teléfono flotante con la pantalla real del diseño (el marco viene en la captura)
const Seal: React.FC<{size?: number}> = ({size = 160}) => (
  <div style={{width: size, height: size, borderRadius: size / 2, background: '#FFFFFF', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 20px 50px rgba(0,0,0,0.35)'}}>
    {/* eslint-disable-next-line @remotion/warn-native-media-tag */}
    <img src={ddcSeal} style={{width: size * 0.86, height: size * 0.86}} />
  </div>
);

const Phone: React.FC<{src: string; prev?: string; changeAt?: number; width?: number; float?: boolean}> = ({src, prev, changeAt = 0, width = 372, float = true}) => {
  const frame = useCurrentFrame();
  const h = width * 2.196;
  const fade = prev ? interpolate(frame, [changeAt, changeAt + 22], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) : 1;
  const dy = float ? Math.sin(frame * 0.045) * 7 : 0;
  return (
    <div style={{position: 'relative', width, height: h, transform: `translateY(${dy}px)`, borderRadius: 54, boxShadow: '0 40px 100px rgba(0,0,0,0.55)'}}>
      {prev && (
        // eslint-disable-next-line @remotion/warn-native-media-tag
        <img src={prev} style={{position: 'absolute', inset: 0, width: '100%', height: '100%', borderRadius: 54}} />
      )}
      {/* eslint-disable-next-line @remotion/warn-native-media-tag */}
      <img src={src} style={{position: 'absolute', inset: 0, width: '100%', height: '100%', borderRadius: 54, opacity: fade}} />
    </div>
  );
};

const SideBlock: React.FC<{title: React.ReactNode; body: string; delay?: number; bullets?: string[]}> = ({title, body, delay = 60, bullets}) => {
  const t1 = useFadeUp(delay, 30);
  const t2 = useFadeUp(delay + 30, 30);
  return (
    <div style={{display: 'flex', flexDirection: 'column', gap: 26, maxWidth: 620}}>
      <div style={{...t1, fontFamily: FJ, fontSize: 54, color: D.white, fontWeight: 600, lineHeight: 1.18}}>{title}</div>
      <GrayRule delay={delay + 20} />
      <div style={{...t2, fontFamily: FJ, fontSize: 27, color: D.gray, lineHeight: 1.55, fontWeight: 400}}>{body}</div>
      {bullets && (
        <div style={{display: 'flex', flexDirection: 'column', gap: 14, marginTop: 6}}>
          {bullets.map((b, i) => {
            const st = usePop(delay + 70 + i * 22);
            return (
              <div key={i} style={{...st, display: 'flex', alignItems: 'center', gap: 14}}>
                <div style={{width: 8, height: 8, borderRadius: 4, background: D.light}} />
                <span style={{fontFamily: FJ, fontSize: 24, color: D.light, fontWeight: 500}}>{b}</span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

// ================= U1 — GANCHO (210f) =================

export const U1Hook: React.FC = () => {
  const t1 = usePop(12);
  const t2 = useFadeUp(50);
  const t3 = useFadeUp(95);
  return (
    <Scene duration={210} bg={D.ink}>
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', gap: 36}}>
        <div style={t1}><Seal size={170} /></div>
        <div style={{...t2, fontFamily: FJ, fontSize: 62, color: D.white, fontWeight: 600, textAlign: 'center', maxWidth: 1450, lineHeight: 1.25}}>
          ¿Y si su marca viviera en el iPhone
          <br />
          de cada comprador <span style={{color: D.gray}}>y cada inversor?</span>
        </div>
        <div style={{...t3, fontFamily: FJ, fontSize: 26, color: D.gray, letterSpacing: 3, textTransform: 'uppercase'}}>
          Propuesta · App iOS · Building Experiences
        </div>
      </AbsoluteFill>
    </Scene>
  );
};

// ================= U2 — EL PROBLEMA (300f) =================

const Chip: React.FC<{delay: number; rot: number; children: React.ReactNode}> = ({delay, rot, children}) => {
  const frame = useCurrentFrame();
  const st = usePop(delay);
  const wob = Math.sin((frame + delay) * 0.07) * 1.4;
  return (
    <div style={{...st, transform: `${(st.transform as string) || ''} rotate(${rot + wob}deg)`}}>
      <div style={{background: D.navy, border: `1px solid ${D.gray}44`, borderRadius: 18, padding: '26px 34px', fontFamily: FJ, fontSize: 28, color: D.light, fontWeight: 500, boxShadow: '0 20px 50px rgba(0,0,0,0.4)'}}>
        {children}
      </div>
    </div>
  );
};

export const U2Problem: React.FC = () => {
  return (
    <Scene duration={240} bg={D.ink}>
      <div style={{position: 'absolute', top: 70, left: 120}}>
        <DKicker>El siguiente símbolo de estatus</DKicker>
      </div>
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', gap: 34, paddingBottom: 130}}>
        <Chip delay={15} rot={-2}>🏛 Los grandes players del real estate tienen app propia</Chip>
        <Chip delay={50} rot={1.8}>📲 «Descarguen nuestra app» — otro nivel al abrir una reunión</Chip>
        <Chip delay={80} rot={-1.4}>🔒 Acceso por invitación, con Face ID: un club privado</Chip>
        <Chip delay={110} rot={2}>🥇 Ningún competidor de su mercado la tiene. Todavía.</Chip>
      </AbsoluteFill>
      <DCaption delay={135}>Una marca que construye experiencias merece instalarse en el iPhone de sus clientes.</DCaption>
    </Scene>
  );
};

// ================= U3 — PORTAFOLIO (420f) =================

export const U3Catalog: React.FC = () => {
  const frame = useCurrentFrame();
  const phoneIn = useFadeUp(15, 60);
  return (
    <Scene duration={360} bg={D.ink}>
      <div style={{position: 'absolute', top: 70, left: 120}}>
        <DKicker>Comprar — Todo el portafolio</DKicker>
      </div>
      <AbsoluteFill style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 110, paddingBottom: 100}}>
        <div style={phoneIn}>
          <Phone src={imgCatalogo} prev={imgHome} changeAt={150} width={330} />
        </div>
        <SideBlock
          delay={70}
          title={<>Todo su portafolio,<br />siempre impecable</>}
          body="Cada proyecto con sus renders en máxima calidad — como manda su manual de marca. Filtros por estado, búsqueda por ciudad, y el inventario real al día."
          bullets={['Preventa · En venta · Vendido', '18 residencias · 3 ciudades', 'Renders sin filtros, calidad DDC']}
        />
      </AbsoluteFill>
      {frame > 210 && <DCaption delay={210}>El sello DDC en cada pixel — con el acabado que solo una app nativa transmite.</DCaption>}
    </Scene>
  );
};

// ================= U4 — DETALLE (390f) =================

export const U4Detail: React.FC = () => {
  const phoneIn = useFadeUp(15, 60);
  return (
    <Scene duration={300} bg={D.navy}>
      <div style={{position: 'absolute', top: 70, left: 120}}>
        <DKicker>Comprar — Cada residencia</DKicker>
      </div>
      <AbsoluteFill style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 110, paddingBottom: 100}}>
        <SideBlock
          delay={70}
          title={<>Del render a la<br />obra terminada</>}
          body="Specs completas, precio, entrega — y el toggle que enamora al comprador: ver el render y la obra real de la misma residencia, lado a lado."
          bullets={['Render ↔ Obra terminada', 'Hab · Baños · Sq Ft · Entrega', 'Historia de cada proyecto']}
        />
        <div style={phoneIn}>
          <Phone src={imgDetalle2} prev={imgDetalle} changeAt={150} width={330} />
        </div>
      </AbsoluteFill>
    </Scene>
  );
};

// ================= U4b — RECORRIDO 3D / AR (390f) =================

export const U4bTour: React.FC = () => {
  const phoneIn = useFadeUp(15, 60);
  return (
    <Scene duration={390} bg={D.ink}>
      <div style={{position: 'absolute', top: 70, left: 120}}>
        <DKicker>Comprar — Caminarla antes de que exista</DKicker>
      </div>
      <AbsoluteFill style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 110, paddingBottom: 100}}>
        <div style={phoneIn}>
          <Phone src={imgAr} width={330} />
        </div>
        <SideBlock
          delay={70}
          title={<>Camine la residencia<br />antes de construirla</>}
          body="Recorridos 3D interactivos y realidad aumentada: apunte el teléfono al terreno vacío y vea la villa terminada, ahí. Producido por el mismo estudio que ya hace sus renders."
          bullets={['Recorrido 3D de cada espacio', 'AR: la villa sobre su terreno real', 'Renders + app, un solo proveedor']}
        />
      </AbsoluteFill>
    </Scene>
  );
};

// ================= U5b — OBRA EN VIVO (390f) =================

export const U5bObra: React.FC = () => {
  const phoneIn = useFadeUp(15, 60);
  return (
    <Scene duration={390} bg={D.navy}>
      <div style={{position: 'absolute', top: 70, left: 120}}>
        <DKicker>Invertir — Su proyecto, en vivo</DKicker>
      </div>
      <AbsoluteFill style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 110, paddingBottom: 100}}>
        <SideBlock
          delay={70}
          title={<>El inversionista ve<br />crecer su dinero</>}
          body="Cada hito de obra llega al inversionista con fotos y notificación push. Su capital deja de ser un acto de fe: se convierte en algo que puede ver, semana a semana."
          bullets={['Push de cada hito a sus inversores', 'Fotos del sitio, semana a semana', 'Confianza que financia la próxima ronda']}
        />
        <div style={phoneIn}>
          <Phone src={imgObra} width={330} />
        </div>
      </AbsoluteFill>
    </Scene>
  );
};

// ================= U5 — INVERTIR (300f) =================

export const U5Invest: React.FC = () => {
  const phoneIn = useFadeUp(15, 60);
  return (
    <Scene duration={300} bg={D.ink}>
      <div style={{position: 'absolute', top: 70, left: 120}}>
        <DKicker>Invertir — Las oportunidades</DKicker>
      </div>
      <AbsoluteFill style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 110, paddingBottom: 100}}>
        <div style={phoneIn}>
          <Phone src={imgInvertir} width={330} />
        </div>
        <SideBlock
          delay={70}
          title={<>El pitch de inversión,<br />siempre a mano</>}
          body="ROI estimado, ticket mínimo, meses de obra y porcentaje colocado de cada oportunidad — los números que cierran reuniones, sin abrir la laptop."
          bullets={['ROI anual 12–18%', 'Oportunidades abiertas en vivo', '% colocado por proyecto']}
        />
      </AbsoluteFill>
    </Scene>
  );
};

// ================= U6 — MARCA + PORTAL (390f) =================

export const U6Portal: React.FC = () => {
  const phoneIn = useFadeUp(15, 60);
  return (
    <Scene duration={270} bg={D.navy}>
      <div style={{position: 'absolute', top: 70, left: 120}}>
        <DKicker>Invertir — Acceso privado</DKicker>
      </div>
      <AbsoluteFill style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 110, paddingBottom: 100}}>
        <SideBlock
          delay={70}
          title={<>Un club, no<br />una descarga</>}
          body="La historia de la marca dentro de la app, y un portal de inversores con acceso solo por invitación — credenciales del asesor o Face ID. Exclusividad que se siente."
          bullets={['Acceso por invitación', 'Face ID', 'Su marca, pixel por pixel']}
        />
        <div style={phoneIn}>
          <Phone src={imgPortal} prev={imgNosotros} changeAt={130} width={330} />
        </div>
      </AbsoluteFill>
    </Scene>
  );
};

// ================= U6b — DASHBOARD DEL INVERSOR (360f) =================

export const U6bDash: React.FC = () => {
  const phoneIn = useFadeUp(15, 60);
  return (
    <Scene duration={360} bg={D.ink}>
      <div style={{position: 'absolute', top: 70, left: 120}}>
        <DKicker>Invertir — Su patrimonio, en su bolsillo</DKicker>
      </div>
      <AbsoluteFill style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 110, paddingBottom: 100}}>
        <div style={phoneIn}>
          <Phone src={imgDash} width={330} />
        </div>
        <SideBlock
          delay={70}
          title={<>Detrás del Face ID:<br />su inversión</>}
          body="El inversor abre la app y ve su número: aporte, avance, valor proyectado, documentos y la próxima distribución. Una atención de este nivel no la ofrece ningún otro desarrollador de su mercado — y eso también se presume."
          bullets={['Avance de obra y ROI proyectado', 'Documentos y estados de cuenta', 'Hitos con notificación push']}
        />
      </AbsoluteFill>
    </Scene>
  );
};

// ================= U7 — CIERRE (300f) =================

export const U7Close: React.FC = () => {
  const t1 = useFadeUp(15);
  const t2 = useFadeUp(75);
  const t3 = useFadeUp(135);
  return (
    <Scene duration={300} bg="#0A1122">
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', gap: 44}}>
        <div style={{...t1, fontFamily: FJ, fontSize: 64, color: D.white, fontWeight: 600, textAlign: 'center', lineHeight: 1.3}}>
          Una app a la altura
          <br />
          de sus residencias.
        </div>
        <div style={{...t2, marginTop: 26, display: 'flex', alignItems: 'center', gap: 46}}>
          <Seal size={130} />
          <div style={{width: 1, height: 70, background: '#3A465C'}} />
          {/* eslint-disable-next-line @remotion/warn-native-media-tag */}
          <img src={borsogaStack} style={{height: 130, width: 'auto', display: 'block'}} />
        </div>
        <div style={{...t3, fontFamily: FJ, fontSize: 24, color: D.gray, letterSpacing: 5, textTransform: 'uppercase', fontWeight: 500}}>
          Veámoslo en vivo
        </div>
      </AbsoluteFill>
    </Scene>
  );
};

const BorsogaLogoWhite: React.FC<{width?: number}> = ({width = 300}) => (
  // eslint-disable-next-line @remotion/warn-native-media-tag
  <img src={logoBorsoga} style={{width, height: 'auto', display: 'block'}} />
);
