import React from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import '@fontsource/poppins/400.css';
import '@fontsource/poppins/500.css';
import '@fontsource/poppins/600.css';
import '@fontsource/poppins/700.css';
import '@fontsource/poppins/800.css';
import {C} from './theme';
import {S1Intro, S2Fax, S2bChannels, S3Eligibility, S4Queue, S5Family, S6Close} from './scenes';

export const Video: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: C.bg}}>
      <Sequence from={0} durationInFrames={180}>
        <S1Intro />
      </Sequence>
      <Sequence from={180} durationInFrames={540}>
        <S2Fax />
      </Sequence>
      <Sequence from={720} durationInFrames={330}>
        <S2bChannels />
      </Sequence>
      <Sequence from={1050} durationInFrames={360}>
        <S3Eligibility />
      </Sequence>
      <Sequence from={1410} durationInFrames={450}>
        <S4Queue />
      </Sequence>
      <Sequence from={1860} durationInFrames={450}>
        <S5Family />
      </Sequence>
      <Sequence from={2310} durationInFrames={360}>
        <S6Close />
      </Sequence>
    </AbsoluteFill>
  );
};
