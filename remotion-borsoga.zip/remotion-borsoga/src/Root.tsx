import React from 'react';
import {Composition} from 'remotion';
import {Video} from './Video';
import {Video2} from './Video2';
import {Video3} from './Video3';
import {VideoIG} from './VideoIG';

export const Root: React.FC = () => {
  return (
    <>
      <Composition
        id="Demo"
        component={Video}
        durationInFrames={2670}
        fps={30}
        width={1920}
        height={1080}
      />
      <Composition
        id="Demo2"
        component={Video2}
        durationInFrames={2850}
        fps={30}
        width={1920}
        height={1080}
      />
      <Composition
        id="Demo3"
        component={Video3}
        durationInFrames={3120}
        fps={30}
        width={1920}
        height={1080}
      />
      <Composition
        id="InstagramReel"
        component={VideoIG}
        durationInFrames={300}
        fps={30}
        width={1080}
        height={1920}
      />
    </>
  );
};
