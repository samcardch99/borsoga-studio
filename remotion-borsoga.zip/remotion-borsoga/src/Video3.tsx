import React from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import '@fontsource/jost/400.css';
import '@fontsource/jost/500.css';
import '@fontsource/jost/600.css';
import '@fontsource/jost/700.css';
import {U1Hook, U2Problem, U3Catalog, U4Detail, U4bTour, U5bObra, U5Invest, U6Portal, U6bDash, U7Close} from './scenes3';

export const Video3: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: '#0F1931'}}>
      <Sequence from={0} durationInFrames={210}><U1Hook /></Sequence>
      <Sequence from={210} durationInFrames={240}><U2Problem /></Sequence>
      <Sequence from={450} durationInFrames={360}><U3Catalog /></Sequence>
      <Sequence from={810} durationInFrames={300}><U4Detail /></Sequence>
      <Sequence from={1110} durationInFrames={390}><U4bTour /></Sequence>
      <Sequence from={1500} durationInFrames={300}><U5Invest /></Sequence>
      <Sequence from={1800} durationInFrames={270}><U6Portal /></Sequence>
      <Sequence from={2070} durationInFrames={360}><U6bDash /></Sequence>
      <Sequence from={2430} durationInFrames={390}><U5bObra /></Sequence>
      <Sequence from={2820} durationInFrames={300}><U7Close /></Sequence>
    </AbsoluteFill>
  );
};
