import React from 'react';
import {AbsoluteFill, Sequence, interpolate, useCurrentFrame} from 'remotion';
import '@fontsource/poppins/400.css';
import '@fontsource/poppins/600.css';
import '@fontsource/poppins/800.css';
import logoBorsoga from './logo-borsoga.svg';

// ============================================================
// PLANTILLA REEL DE INSTAGRAM — 1080x1920 (9:16) · 30 fps
// Edita los textos/escenas y renderiza con:
//   npx remotion render src/index.ts InstagramReel out/reel.mp4
// ============================================================

const FP = "'Poppins', sans-serif";

const Fade: React.FC<{delay?: number; children: React.ReactNode}> = ({delay = 0, children}) => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [delay, delay + 20], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const y = interpolate(frame, [delay, delay + 20], [40, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return <div style={{opacity: o, transform: `translateY(${y}px)`}}>{children}</div>;
};

const SceneIG: React.FC<{duration: number; bg?: string; children: React.ReactNode}> = ({duration, bg = '#000', children}) => {
  const frame = useCurrentFrame();
  const opacity = interpolate(frame, [0, 12, duration - 12, duration], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill style={{background: bg, opacity, justifyContent: 'center', alignItems: 'center', padding: 90}}>
      {children}
    </AbsoluteFill>
  );
};

export const VideoIG: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      {/* Escena 1 — gancho (3s) */}
      <Sequence from={0} durationInFrames={90}>
        <SceneIG duration={90}>
          <Fade delay={8}>
            <div style={{fontFamily: FP, fontSize: 92, fontWeight: 800, color: '#fff', textAlign: 'center', lineHeight: 1.15, textTransform: 'uppercase'}}>
              Tu marca
              <br />
              merece video.
            </div>
          </Fade>
        </SceneIG>
      </Sequence>

      {/* Escena 2 — mensaje (4s) */}
      <Sequence from={90} durationInFrames={120}>
        <SceneIG duration={120}>
          <Fade delay={10}>
            <div style={{fontFamily: FP, fontSize: 58, fontWeight: 600, color: '#fff', textAlign: 'center', lineHeight: 1.35}}>
              Diseño, 3D y desarrollo
              <br />
              <span style={{opacity: 0.6}}>bajo un mismo techo.</span>
            </div>
          </Fade>
        </SceneIG>
      </Sequence>

      {/* Escena 3 — cierre con logo (3s) */}
      <Sequence from={210} durationInFrames={90}>
        <SceneIG duration={90}>
          <Fade delay={8}>
            <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 50}}>
              {/* eslint-disable-next-line @remotion/warn-native-media-tag */}
              <img src={logoBorsoga} style={{width: 560}} />
              <div style={{fontFamily: FP, fontSize: 34, color: '#9A9A9A', letterSpacing: 6, textTransform: 'uppercase'}}>
                @borsogastudio
              </div>
            </div>
          </Fade>
        </SceneIG>
      </Sequence>
    </AbsoluteFill>
  );
};
