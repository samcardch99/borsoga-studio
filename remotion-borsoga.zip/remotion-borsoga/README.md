# Borsoga · Videos en Remotion

Proyecto de videos programados con [Remotion](https://remotion.dev) (React).
Incluye 4 composiciones:

| ID | Contenido | Formato |
|---|---|---|
| `Demo` | Health Partners — portal de referidos (MVP) | 1920×1080 |
| `Demo2` | Health Partners — "El cuidado continuo" (ops + RPM) | 1920×1080 |
| `Demo3` | DDC Developments — app iOS | 1920×1080 |
| `InstagramReel` | Plantilla reel 9:16 lista para editar | 1080×1920 |

## Instalación (una sola vez)

1. Instala Node.js LTS si no lo tienes: `brew install node`
   (o descárgalo de https://nodejs.org)
2. En Terminal, dentro de esta carpeta:

```bash
npm install
```

## Uso

**Editor visual con preview en vivo:**

```bash
npx remotion studio
```

Se abre en el navegador: eliges la composición, ves los cambios del código en
vivo y puedes renderizar desde ahí mismo.

**Renderizar por terminal:**

```bash
npx remotion render src/index.ts InstagramReel out/reel.mp4
npx remotion render src/index.ts Demo3 out/ddc.mp4
```

## Dónde editar

- `src/VideoIG.tsx` — el reel de Instagram (textos y escenas comentados).
- `src/theme.ts` — paleta y tipografías de Health Partners.
- `src/scenes*.tsx` — escenas de cada video.
- `src/app/` — pantallas de la app DDC. `src/fax-scan.jpg`, `src/map-miami.jpg` — assets.

La música de los videos entregados se generó por código (no está en el
proyecto); los renders salen sin audio y puedes montarles pista en cualquier
editor, o pedirme que te pase los .wav.

## Formatos Instagram

- Reel / Story: 1080×1920 (ya configurado en `InstagramReel`)
- Post cuadrado: duplica la composición en `src/Root.tsx` con 1080×1080.
